#!/usr/bin/env bash
set -euo pipefail
name=${1:-langfuse-aio}
wait_health() {
  for ((i=0;i<180;i++)); do
    state=$(docker inspect --format '{{.State.Status}} {{.State.Health.Status}}' "$name")
    case "$state" in 'running healthy') return 0;; exited*|dead*) docker logs --tail 100 "$name"; return 1;; esac
    sleep 10
  done
  docker logs --tail 100 "$name"; return 1
}
wait_health
printf '\n=== Single container / internal processes ===\n'
docker ps --filter "name=^/${name}$"
docker top "$name"
docker exec "$name" python3 /opt/aio/aio.py health
printf '\n=== Restart with same volume ===\n'
docker restart -t 150 "$name" >/dev/null
wait_health
docker exec "$name" python3 /opt/aio/aio.py health
printf 'PASS: startup, internal health and restart. Trace ingestion/persistence still require functional tests.\n'
