import importlib.util
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

spec=importlib.util.spec_from_file_location('aio',Path(__file__).resolve().parents[1]/'scripts/aio.py')
aio=importlib.util.module_from_spec(spec); spec.loader.exec_module(aio)

class ConfigTests(unittest.TestCase):
    def test_secrets_are_persistent_and_private(self):
        with tempfile.TemporaryDirectory() as root:
            p=Path(root)
            a=aio.credentials(p,True)
            self.assertEqual(a,aio.credentials(p,True))
            self.assertEqual((p/'secrets.json').stat().st_mode & 0o777,0o600)
            self.assertEqual(len(a['encryption_key']),64)
            self.assertEqual(len(a['s3_password']),32)
    def test_missing_secret_with_data_refused(self):
        with tempfile.TemporaryDirectory() as root:
            p=Path(root); (p/'postgres').mkdir(); (p/'postgres/PG_VERSION').write_text('17')
            with self.assertRaises(RuntimeError): aio.credentials(p,True)
    def test_internal_endpoints_and_single_node(self):
        with tempfile.TemporaryDirectory() as root, patch.dict(os.environ,{'AIO_S3_PUBLIC_URL':'https://s3.example.test'},clear=True):
            e=aio.app_env(aio.credentials(Path(root),True))
            self.assertIn('@127.0.0.1:5432/',e['DATABASE_URL'])
            self.assertEqual(e['CLICKHOUSE_CLUSTER_ENABLED'],'false')
            self.assertEqual(e['LANGFUSE_S3_EVENT_UPLOAD_ENDPOINT'],'http://127.0.0.1:9090')
            self.assertEqual(e['LANGFUSE_S3_MEDIA_UPLOAD_ENDPOINT'],'https://s3.example.test')
            self.assertEqual(e['DIRECT_URL'],e['DATABASE_URL'])
    def test_offline_environment_overrides(self):
        with tempfile.TemporaryDirectory() as root, patch.dict(os.environ, {'TELEMETRY_ENABLED':'true','HTTP_PROXY':'http://proxy.invalid:8080','REDIS_URL':'redis://external.invalid'}, clear=True):
            e=aio.app_env(aio.credentials(Path(root),True))
            self.assertEqual(e['TELEMETRY_ENABLED'],'false')
            self.assertEqual(e['AWS_EC2_METADATA_DISABLED'],'true')
            self.assertNotIn('HTTP_PROXY',e)
            self.assertNotIn('REDIS_URL',e)
            self.assertIn('127.0.0.1',e['NO_PROXY'])
    def test_missing_or_invalid_secret_refused(self):
        with tempfile.TemporaryDirectory() as root:
            p=Path(root)
            with self.assertRaises(RuntimeError): aio.credentials(p)
            (p/'secrets.json').write_text('{}')
            with self.assertRaises(RuntimeError): aio.credentials(p,True)

if __name__=='__main__': unittest.main()
