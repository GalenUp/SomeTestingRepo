#!/usr/bin/env bash
# Full offline gate. Leaves failed container/volume for investigation.
set -Eeuo pipefail
cd "$(dirname "$0")/.."
image=${AIO_IMAGE:-langfuse-all-in-one:0.2.0}
mkdir -p artifacts
rm -f artifacts/offline-pass.txt
id=$(docker image inspect -f '{{.Id}}' "$image")
name="lf-offline-$(date +%s)-$$"
volume="$name-data"
# Throwaway random credentials; never use for deployment. Not printed or saved in project.
key=$(python3 -c 'import secrets; print(secrets.token_hex(20))')
export LANGFUSE_INIT_ORG_ID="offline-org" LANGFUSE_INIT_ORG_NAME="Offline smoke test"
export LANGFUSE_INIT_PROJECT_ID="offline-project" LANGFUSE_INIT_PROJECT_NAME="Offline smoke test"
export LANGFUSE_INIT_PROJECT_PUBLIC_KEY="pk-lf-$key" LANGFUSE_INIT_PROJECT_SECRET_KEY="sk-lf-$key"
export LANGFUSE_INIT_USER_EMAIL="offline@example.invalid" LANGFUSE_INIT_USER_NAME="Offline Tester" LANGFUSE_INIT_USER_PASSWORD="A!$key"
cleanup_error() {
  echo "FAIL. Preserving $name and $volume for diagnosis." >&2
  docker logs --tail 200 "$name" > "artifacts/$name.log" 2>&1 || true
  echo "Inspect: docker logs $name; docker inspect $name" >&2
}
trap cleanup_error ERR
start() {
  docker run -d --name "$name" --network none --pull=never --restart=no --stop-timeout 150 \
    -e NEXTAUTH_URL=http://localhost:3000 -e AIO_S3_PUBLIC_URL=http://localhost:9090 \
    -e LANGFUSE_INIT_ORG_ID -e LANGFUSE_INIT_ORG_NAME -e LANGFUSE_INIT_PROJECT_ID -e LANGFUSE_INIT_PROJECT_NAME \
    -e LANGFUSE_INIT_PROJECT_PUBLIC_KEY -e LANGFUSE_INIT_PROJECT_SECRET_KEY \
    -e LANGFUSE_INIT_USER_EMAIL -e LANGFUSE_INIT_USER_NAME -e LANGFUSE_INIT_USER_PASSWORD \
    -v "$volume:/data" "$id" >/dev/null
  [[ $(docker inspect -f '{{.HostConfig.NetworkMode}}' "$name") == none ]]
}
wait_ready() {
  local state
  for ((i=0;i<180;i++)); do
    state=$(docker inspect -f '{{.State.Status}} {{.State.Health.Status}}' "$name")
    case "$state" in 'running healthy') return 0;; exited*|dead*) return 1;; esac
    sleep 10
  done
  return 1
}
docker volume create "$volume" >/dev/null
start
wait_ready
docker exec "$name" python3 /opt/aio/aio.py health
docker top "$name" > "artifacts/$name-processes.txt"
echo 'PASS: fresh boot with no network'
trace=$(docker exec "$name" python3 /opt/aio/trace_probe.py write)
echo 'PASS: ingestion and asynchronous readback'
docker restart -t 150 "$name" >/dev/null
wait_ready
docker exec "$name" python3 /opt/aio/trace_probe.py read "$trace"
echo 'PASS: restart and trace persistence'
docker stop -t 150 "$name" >/dev/null
docker rm "$name" >/dev/null
start
wait_ready
docker exec "$name" python3 /opt/aio/trace_probe.py read "$trace"
echo 'PASS: container recreation and trace persistence'
docker logs "$name" > "artifacts/$name.log" 2>&1
docker stop -t 150 "$name" >/dev/null
docker rm "$name" >/dev/null
docker volume rm "$volume" >/dev/null
printf '%s\n' "$id" > artifacts/offline-pass.txt
printf 'PASS: offline acceptance gate, image %s\n' "$id"
