#!/usr/bin/env python3
"""Offline functional probe: standard library only; no SDK download."""
import base64
import datetime
import json
import os
import sys
import time
import urllib.request
import urllib.error
import uuid

BASE = 'http://127.0.0.1:3000'
NAME = 'offline-aio-smoke'

def call(path, data=None):
    auth = os.environ['LANGFUSE_INIT_PROJECT_PUBLIC_KEY'] + ':' + os.environ['LANGFUSE_INIT_PROJECT_SECRET_KEY']
    req = urllib.request.Request(BASE + path, data=None if data is None else json.dumps(data).encode(),
        headers={'Authorization': 'Basic ' + base64.b64encode(auth.encode()).decode(), 'Content-Type':'application/json'})
    with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req, timeout=10) as response:
        return json.load(response)

def wait_trace(trace):
    deadline = time.monotonic() + 240
    while time.monotonic() < deadline:
        try:
            obj = call('/api/public/traces/' + trace)
            if obj.get('id') == trace and obj.get('name') == NAME:
                print('Trace verified: ' + trace, file=sys.stderr)
                return
        except (OSError, ValueError):
            pass
        time.sleep(3)
    raise RuntimeError('Trace not readable within 240 seconds; inspect Web/Worker logs')

def main():
    if sys.argv[1] == 'write':
        trace = uuid.uuid4().hex
        now = datetime.datetime.now(datetime.timezone.utc).isoformat()
        body = {'batch': [{'id': str(uuid.uuid4()), 'type':'trace-create', 'timestamp':now,
            'body':{'id':trace,'name':NAME,'timestamp':now,'input':{'offline':True},'output':'ok'}}]}
        deadline = time.monotonic() + 90
        while True:
            try:
                result = call('/api/public/ingestion', body)
                if result.get('errors') or not result.get('successes'):
                    raise RuntimeError('Ingestion returned unsuccessful batch: ' + str(result)[:500])
                break
            except urllib.error.HTTPError as exc:
                if exc.code not in (401, 403, 503) or time.monotonic() >= deadline:
                    raise
                time.sleep(3)
        wait_trace(trace)
        print(trace)
    elif sys.argv[1] == 'read':
        wait_trace(sys.argv[2])
    else:
        raise SystemExit('usage: trace_probe.py write | read TRACE_ID')

if __name__ == '__main__':
    main()
