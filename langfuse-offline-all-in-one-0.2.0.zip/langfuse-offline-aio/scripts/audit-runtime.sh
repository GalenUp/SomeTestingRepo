#!/usr/bin/env bash
# Guard our own runtime entrypoint against common package downloads.
# Not a proof about arbitrary upstream code; real network-none test is required.
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PY'
from pathlib import Path
import re
p=Path('scripts/aio.py')
patterns=[r'\b(?:apt(?:-get)?|apk|dnf|yum)\s+(?:install|add|update|upgrade)',r'\b(?:pip3?|npm|pnpm|yarn)\s+(?:install|add|ci)',r'\bdocker\s+(?:pull|run|compose)',r'\b(?:wget|curl)\s+[^\n]*https?://']
for pattern in patterns:
    if re.search(pattern,p.read_text(),re.I):
        raise SystemExit('Runtime audit rejected: '+pattern)
print('PASS: no common package-install or external download commands in custom runtime entrypoint (heuristic).')
PY
