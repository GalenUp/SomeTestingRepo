#!/usr/bin/env bash
# Read-only, except docker info contacts an already-running daemon.
set -u
printf '\n=== OS / architecture ===\n'
cat /etc/os-release 2>/dev/null || true
uname -a
printf '\n=== CPU / memory ===\n'
nproc; free -h
if grep -qw avx2 /proc/cpuinfo; then echo 'AVX2: present'; else echo 'AVX2: missing or not visible'; fi
printf '\n=== cgroup limits ===\n'
for f in /sys/fs/cgroup/{memory.max,cpu.max,memory/memory.limit_in_bytes,cpu/cpu.cfs_quota_us,cpu/cpu.cfs_period_us}; do
  if [ -r "$f" ]; then printf '%s: ' "$f"; cat "$f"; fi
done
printf '\n=== storage ===\n'
df -h / "$PWD" /root/autodl-tmp 2>/dev/null || true
printf '\n=== virtualization ===\n'
systemd-detect-virt 2>/dev/null || true
[ ! -f /.dockerenv ] || echo '/.dockerenv present'
cat /proc/1/cgroup 2>/dev/null || true
printf '\n=== Docker ===\n'
if ! command -v docker >/dev/null; then echo 'NO_DOCKER_CLI'; exit 2; fi
if ! docker info --format 'Server={{.ServerVersion}} Arch={{.Architecture}} CPUs={{.NCPU}} MemoryBytes={{.MemTotal}} Root={{.DockerRootDir}}'; then
  echo 'NO_USABLE_DOCKER_DAEMON'; exit 2
fi
docker version --format 'Client={{.Client.Version}} Server={{.Server.Version}}'
printf '\n=== Docker available ===\n'
