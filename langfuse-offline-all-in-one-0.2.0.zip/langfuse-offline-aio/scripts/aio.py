#!/usr/bin/env python3
"""Experimental single-container process supervisor for Langfuse v3."""
import base64
import fcntl
import json
import os
from pathlib import Path
import pwd
import secrets
import signal
import subprocess as sp
import sys
import time
import urllib.request

DATA = Path('/data')
RUN = Path('/run/langfuse-aio')
READY = RUN / 'ready'
PG = Path('/usr/libexec/postgresql17')
NAMES = ('pg_password','ch_password','redis_password','s3_password','salt','encryption_key','nextauth_secret')
PROCS = {}
STOP = False


def log(msg):
    print('[aio] ' + msg, flush=True)


def atomic_write(path, text, mode=0o600):
    tmp = path.with_name(path.name + '.tmp')
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_NOFOLLOW, mode)
    with os.fdopen(fd, 'w') as f:
        os.fchmod(f.fileno(), mode)
        f.write(text)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)
    fd = os.open(path.parent, os.O_DIRECTORY)
    try: os.fsync(fd)
    finally: os.close(fd)


def credentials(data=DATA, create=False):
    path = data / 'secrets.json'
    if not path.exists():
        if not create:
            raise RuntimeError('missing secrets.json')
        if any((data / name).exists() and any((data / name).iterdir())
               for name in ('postgres','clickhouse','redis','minio')):
            raise RuntimeError('data exists but secrets.json missing; restore secrets, do not regenerate')
        atomic_write(path, json.dumps({k: secrets.token_hex(16 if k == 's3_password' else 32) for k in NAMES}) + '\n')
    values = json.loads(path.read_text())
    for k in NAMES:
        v = values.get(k, '')
        if not isinstance(v, str) or len(v) != (32 if k == 's3_password' else 64) or any(c not in '0123456789abcdef' for c in v):
            raise RuntimeError('invalid persistent secret: ' + k)
    return values


def identity(user):
    p = pwd.getpwnam(user)
    return dict(user=p.pw_uid, group=p.pw_gid, extra_groups=[])


def owned_dir(path, user, mode=0o700):
    path.mkdir(parents=True, exist_ok=True)
    p = pwd.getpwnam(user)
    os.chown(path, p.pw_uid, p.pw_gid)
    path.chmod(mode)


def base_env():
    return {k: v for k,v in os.environ.items() if k in ('PATH','TZ','LANG','LC_ALL')}


def app_env(s):
    e = os.environ.copy()
    # Do not send local database/object-store calls through a proxy.
    for key in ('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy'):
        e.pop(key, None)
    e.update(NO_PROXY='localhost,127.0.0.1,::1', no_proxy='localhost,127.0.0.1,::1',
             TELEMETRY_ENABLED='false', NEXT_TELEMETRY_DISABLED='1', CHECKPOINT_DISABLE='1',
             PRISMA_HIDE_UPDATE_MESSAGE='1', AWS_EC2_METADATA_DISABLED='true')
    endpoint = 'http://127.0.0.1:9090'
    public = e.get('AIO_S3_PUBLIC_URL', 'http://localhost:9090')
    e.update(DATABASE_URL=f"postgresql://langfuse:{s['pg_password']}@127.0.0.1:5432/postgres",
             CLICKHOUSE_URL='http://127.0.0.1:8123',
             CLICKHOUSE_MIGRATION_URL='clickhouse://127.0.0.1:9000',
             CLICKHOUSE_USER='default', CLICKHOUSE_PASSWORD=s['ch_password'],
             CLICKHOUSE_CLUSTER_ENABLED='false', REDIS_HOST='127.0.0.1', REDIS_PORT='6379',
             REDIS_AUTH=s['redis_password'], REDIS_TLS_ENABLED='false',
             SALT=s['salt'], ENCRYPTION_KEY=s['encryption_key'], NEXTAUTH_SECRET=s['nextauth_secret'],
             NEXTAUTH_URL=e.get('NEXTAUTH_URL','http://localhost:3000'),
             HOSTNAME='0.0.0.0', NODE_ENV='production', DOCKER_BUILD='0',
             LANGFUSE_AUTO_POSTGRES_MIGRATION_DISABLED='false',
             LANGFUSE_AUTO_CLICKHOUSE_MIGRATION_DISABLED='false',
             LANGFUSE_USE_AZURE_BLOB='false', LANGFUSE_USE_OCI_NATIVE_OBJECT_STORAGE='false')
    e['DIRECT_URL'] = e['DATABASE_URL']
    e['LANGFUSE_S3_BATCH_EXPORT_ENABLED'] = e.get('LANGFUSE_S3_BATCH_EXPORT_ENABLED', 'false')
    e.pop('REDIS_CONNECTION_STRING',None)
    e.pop('REDIS_URL',None)
    for kind, prefix in (('EVENT','events/'),('MEDIA','media/'),('BATCH_EXPORT','exports/')):
        p = f'LANGFUSE_S3_{kind}_UPLOAD_' if kind != 'BATCH_EXPORT' else 'LANGFUSE_S3_BATCH_EXPORT_'
        for k,v in dict(BUCKET='langfuse',REGION='us-east-1',ACCESS_KEY_ID='langfuse',
                        SECRET_ACCESS_KEY=s['s3_password'],ENDPOINT=public if kind=='MEDIA' else endpoint,
                        FORCE_PATH_STYLE='true',PREFIX=prefix).items(): e[p+k]=v
    e['LANGFUSE_S3_BATCH_EXPORT_EXTERNAL_ENDPOINT']=public
    e.setdefault('LANGFUSE_S3_BATCH_EXPORT_ENABLED','false')
    return e


def launch(name, argv, user, cwd='/', env=None):
    if STOP: raise RuntimeError('shutdown requested')
    e = base_env() if env is None else env.copy()
    e.setdefault('HOME', cwd if user=='nextjs' else str(DATA))
    log('starting ' + name)
    PROCS[name] = sp.Popen(argv, cwd=cwd, env=e, start_new_session=True, **identity(user))


def check_children():
    for name,p in PROCS.items():
        if p.poll() is not None:
            raise RuntimeError(f'{name} exited (code {p.returncode})')


def cmd_ok(argv, env=None, timeout=5, expected=None):
    try:
        p=sp.run(argv, env=env, timeout=timeout, stdout=sp.PIPE, stderr=sp.DEVNULL, text=True)
        return p.returncode==0 and (expected is None or p.stdout.strip()==expected)
    except (OSError, sp.TimeoutExpired): return False


def http_ok(url, auth=None, expected=None):
    try:
        req=urllib.request.Request(url)
        if auth: req.add_header('Authorization','Basic '+base64.b64encode(auth.encode()).decode())
        with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req,timeout=4) as r:
            return r.status==200 and (expected is None or r.read().decode().strip()==expected)
    except (OSError, ValueError): return False


def pg_ok(s):
    return cmd_ok([str(PG/'psql'),'-X','-h','127.0.0.1','-U','langfuse','-d','postgres','-Atc','SELECT 1'],
                  env={**base_env(),'PGPASSWORD':s['pg_password'],'PGCONNECT_TIMEOUT':'3'},expected='1')


def ch_ok(s):
    return http_ok('http://127.0.0.1:8123/?query=SELECT%201','default:'+s['ch_password'],expected='1')


def redis_ok(s):
    return cmd_ok(['redis-cli','-h','127.0.0.1','ping'],env={**base_env(),'REDISCLI_AUTH':s['redis_password']},expected='PONG')


def mc_env(s):
    return {**base_env(),'MC_CONFIG_DIR':str(RUN/'mc'),
            'MC_HOST_local':f"http://langfuse:{s['s3_password']}@127.0.0.1:9090"}


def minio_ok(s):
    return http_ok('http://127.0.0.1:9090/minio/health/ready') and cmd_ok(['mc','stat','local/langfuse'],env=mc_env(s))


def web_ok(): return http_ok('http://127.0.0.1:3000/api/public/health?failIfDatabaseUnavailable=true')
def worker_ok(): return http_ok('http://127.0.0.1:3030/api/health')


def wait_for(name, check, seconds=180):
    deadline=time.monotonic()+seconds
    while not STOP and time.monotonic()<deadline:
        check_children()
        if check():
            log(name+' ready'); return
        time.sleep(2)
    raise RuntimeError(name+' readiness failed or shutdown requested')


def init_pg(s):
    target=DATA/'postgres'
    owned_dir(target,'postgres')
    if not (target/'PG_VERSION').exists():
        if any(target.iterdir()): raise RuntimeError('partial PostgreSQL init; inspect data before retrying')
        pw=RUN/'pg-password'
        atomic_write(pw,s['pg_password']+'\n')
        p=pwd.getpwnam('postgres'); os.chown(pw,p.pw_uid,p.pw_gid)
        try:
            sp.run([str(PG/'initdb'),'-D',str(target),'-U','langfuse','--encoding=UTF8','--locale=C',
                    '--auth-local=trust','--auth-host=scram-sha-256','--pwfile='+str(pw)],
                   env={**base_env(),'HOME':str(target)},check=True,timeout=180,**identity('postgres'))
        finally: pw.unlink(missing_ok=True)
    elif (target/'PG_VERSION').read_text().strip()!='17':
        raise RuntimeError('PostgreSQL major version mismatch; migration required')
    launch('postgres',[str(PG/'postgres'),'-D',str(target),'-h','127.0.0.1','-k',str(target)],'postgres')


def start_ch(s):
    target=DATA/'clickhouse'; owned_dir(target,'aioch')
    logs=DATA/'clickhouse-logs'; owned_dir(logs,'aioch')
    cfg=Path('/etc/clickhouse-server/config.d'); users=Path('/etc/clickhouse-server/users.d')
    cfg.mkdir(exist_ok=True); users.mkdir(exist_ok=True)
    atomic_write(cfg/'zz-aio.xml',f'''<clickhouse>
<listen_host replace="replace">127.0.0.1</listen_host>
<path replace="replace">{target}/</path>
<tmp_path replace="replace">{target}/tmp/</tmp_path>
<user_files_path replace="replace">{target}/user_files/</user_files_path>
<format_schema_path replace="replace">{target}/format_schemas/</format_schema_path>
<access_control_path replace="replace">{target}/access/</access_control_path>
<logger><log replace="replace">{logs}/server.log</log><errorlog replace="replace">{logs}/error.log</errorlog><console>true</console></logger>
<mark_cache_size>268435456</mark_cache_size><uncompressed_cache_size>134217728</uncompressed_cache_size>
</clickhouse>''',0o644)
    import hashlib
    digest=hashlib.sha256(s['ch_password'].encode()).hexdigest()
    p=users/'zz-aio.xml'
    atomic_write(p,f'''<clickhouse><users><default><password remove="remove"/><password_sha256_hex>{digest}</password_sha256_hex><networks replace="replace"><ip>127.0.0.1</ip></networks><access_management>1</access_management></default></users></clickhouse>''',0o640)
    os.chown(p,0,pwd.getpwnam('aioch').pw_gid)
    launch('clickhouse',['clickhouse','server','--config-file=/etc/clickhouse-server/config.xml'],'aioch',env={**base_env(),'CLICKHOUSE_WATCHDOG_ENABLE':'0'})


def start_redis(s):
    target=DATA/'redis'; owned_dir(target,'aioredis')
    p=RUN/'redis.conf'
    atomic_write(p,f'bind 127.0.0.1\nport 6379\ndir {target}\nappendonly yes\nappendfsync everysec\nmaxmemory-policy noeviction\nrequirepass {s["redis_password"]}\n',0o640)
    os.chown(p,0,pwd.getpwnam('aioredis').pw_gid)
    launch('redis',['redis-server',str(p)],'aioredis')


def start_minio(s):
    target=DATA/'minio'; owned_dir(target,'aiominio')
    env={**base_env(),'HOME':str(target),'MINIO_ROOT_USER':'langfuse','MINIO_ROOT_PASSWORD':s['s3_password'],'MINIO_UPDATE':'off'}
    # No console port is published. Public API port is required for browser presigned URLs.
    launch('minio',['minio','server','--address','0.0.0.0:9090','--console-address','127.0.0.1:9091',str(target)],'aiominio',cwd=str(target),env=env)


def shutdown():
    READY.unlink(missing_ok=True)
    # Stop in reverse dependency order. Use SIGINT for PostgreSQL fast shutdown.
    for name,p in reversed(list(PROCS.items())):
        if p.poll() is not None: continue
        log('stopping '+name)
        try:
            if name=='postgres': p.send_signal(signal.SIGINT)
            else: os.killpg(p.pid,signal.SIGTERM)
        except ProcessLookupError: continue
        try: p.wait(timeout=20)
        except sp.TimeoutExpired:
            log(name+' exceeded shutdown timeout; forcing termination')
            try: os.killpg(p.pid,signal.SIGKILL)
            except ProcessLookupError: pass
            p.wait()


def handle_signal(*_):
    global STOP
    STOP=True


def run():
    if os.geteuid()!=0: raise RuntimeError('prototype requires root supervisor to drop privileges for services')
    DATA.mkdir(exist_ok=True); RUN.mkdir(mode=0o755,parents=True,exist_ok=True)
    lock=(DATA/'.aio.lock').open('a')
    try: fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError: raise RuntimeError('data directory already in use')
    READY.unlink(missing_ok=True)
    signal.signal(signal.SIGTERM,handle_signal); signal.signal(signal.SIGINT,handle_signal)
    try:
        s=credentials(create=True)
        init_pg(s); start_ch(s); start_redis(s); start_minio(s)
        wait_for('PostgreSQL',lambda:pg_ok(s)); wait_for('ClickHouse',lambda:ch_ok(s))
        wait_for('Redis',lambda:redis_ok(s)); wait_for('MinIO API',lambda:http_ok('http://127.0.0.1:9090/minio/health/ready'))
        wait_for('MinIO bucket',lambda:cmd_ok(['mc','mb','--ignore-existing','local/langfuse'],env=mc_env(s)))
        wait_for('MinIO authenticated access',lambda:minio_ok(s))
        e=app_env(s)
        e['HOME']='/tmp'
        launch('web',['./web/entrypoint.sh','node','./web/server.js','--keepAliveTimeout','110000'], 'nextjs',cwd='/app',env={**e,'PORT':'3000'})
        wait_for('Web (including upstream migrations)',web_ok,seconds=900)
        launch('worker',['./worker/entrypoint.sh','node','worker/dist/index.js'],'nextjs',cwd='/opt/worker-app',env={**e,'PORT':'3030'})
        wait_for('Worker',worker_ok,seconds=300)
        READY.touch(); log('all six services ready')
        while not STOP:
            check_children(); time.sleep(1)
        return 0
    except Exception as exc:
        log(f'ERROR: {exc}'); return 0 if STOP else 1
    finally:
        shutdown(); lock.close()


def health():
    if not READY.exists(): return 1
    try:
        s=credentials()
        checks=(('postgres',lambda:pg_ok(s)),('clickhouse',lambda:ch_ok(s)),('redis',lambda:redis_ok(s)),('minio',lambda:minio_ok(s)),('web',web_ok),('worker',worker_ok))
        for name,fn in checks:
            if not fn(): log(name+' unhealthy'); return 1
        return 0
    except Exception as exc:
        log(f'health error: {exc}'); return 1


if __name__=='__main__':
    mode=sys.argv[1] if len(sys.argv)>1 else 'run'
    if mode not in ('run','health'): sys.exit('usage: aio.py [run|health]')
    sys.exit(run() if mode=='run' else health())
