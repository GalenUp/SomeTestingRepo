#!/usr/bin/env bash
# Export only the exact image that passed the offline gate.
set -euo pipefail
cd "$(dirname "$0")"
image=${AIO_IMAGE:-langfuse-all-in-one:0.2.0}
id=$(docker image inspect -f '{{.Id}}' "$image")
[[ -f artifacts/offline-pass.txt && $(cat artifacts/offline-pass.txt) == "$id" ]] || { echo 'Run bash tests/offline.sh successfully for this image first.' >&2; exit 1; }
mkdir -p artifacts
file=langfuse-offline-all-in-one-0.2.0.tar.gz
docker save "$image" | gzip -1 > "artifacts/$file.tmp"
mv "artifacts/$file.tmp" "artifacts/$file"
(cd artifacts; sha256sum "$file" > "$file.sha256")
echo "Exported artifacts/$file and checksum. No data volumes or runtime secrets included."
