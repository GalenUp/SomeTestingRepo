#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
image=${AIO_IMAGE:-langfuse-all-in-one:0.2.0}
: "${ACR_IMAGE:?Set ACR_IMAGE to full approved ACR registry/namespace/repo:tag}"
id=$(docker image inspect -f '{{.Id}}' "$image")
[[ -f artifacts/offline-pass.txt && $(cat artifacts/offline-pass.txt) == "$id" ]] || { echo 'Offline gate not passed for this exact image.' >&2; exit 1; }
# Login separately using approved ACR credentials; no credentials in the script.
docker tag "$id" "$ACR_IMAGE"
docker push "$ACR_IMAGE"
docker image inspect -f '{{range .RepoDigests}}{{println .}}{{end}}' "$ACR_IMAGE" > artifacts/acr-repodigests.txt
