#!/usr/bin/env bash
set -euo pipefail
# Local/private test only. Do not expose MinIO or sign-up UI to public internet.
docker run -d --pull=never --name langfuse-aio --restart=no --stop-timeout 150 \
  -p 127.0.0.1:3000:3000 -p 127.0.0.1:9090:9090 \
  -e NEXTAUTH_URL=http://localhost:3000 \
  -e AIO_S3_PUBLIC_URL=http://localhost:9090 \
  -v langfuse-aio-data:/data \
  "${AIO_IMAGE:-langfuse-all-in-one:0.2.0}"
