# Langfuse Offline All-in-One v0.2.0

**实验工程（尚未在 Docker 中构建或运行）。** 目标是交付一个标准 linux/amd64 Docker/OCI 镜像、一个容器，内部运行 Langfuse Web、Worker、PostgreSQL、ClickHouse、Redis、MinIO。无需额外 Linux 内核、Docker Compose、Docker socket 或 privileged。沿用 v0.1.0 的官方 Web 基础镜像和 Worker 产物；仅在构建阶段下载软件及依赖，运行阶段只初始化本地数据、执行已打包迁移、启动和检查本地进程。适用于 OSS 核心功能验证，非正式生产版本。

## 1. 构建和部署边界

| 阶段 | 联网要求 | 操作 |
|---|---|---|
| 构建 | 有公网或获准的镜像/软件源 | 下载基础镜像、apk 安装、COPY 运行产物、记录摘要 |
| 构建末尾 | RUN --network=none | 验证二进制、Prisma/migrate、迁移文件 |
| 离线验收 | --network none --pull=never | 首次启动、迁移、Trace 写入/读回、重启、重建 |
| 分发 | 获准连接 ACR 或文件传输 | 推送单镜像 / 导出单镜像 tar.gz |
| IT 内网运行 | 仅内网（禁止公网） | 拉取内部 ACR 或载入镜像；挂载数据盘；提供内网 HTTP 服务 |

构建时允许下载，但不在 entrypoint 内运行 apt/apk/pip/npm/wget 等安装或公网下载命令。`scripts/audit-runtime.sh` 对自编入口进行启发式静态检查；真正的判据是离线验收成功。官方代码可能尝试非必要更新检查；网络策略是禁止公网访问的强制措施，禁用 OSS 遥测并不等于应用绝不会尝试任何外部请求。企业版 Langfuse 授权、许可证及遥测政策需另行确认；阿里云 ACR 企业版不等于 Langfuse 企业版。

## 2. 有网构建主机：按顺序执行

解压后进入 `langfuse-offline-aio`。需要 Bash、Python 3、Docker Engine/BuildKit、gzip、sha256sum；建议 x86_64（AVX2，ClickHouse 可能还需要 x86-64-v3）、8–16 核、32 GiB 内存、100 GB 可用磁盘。AutoDL 普通容器往往不能运行 Docker；若检测失败，改用之前支持六容器的服务器或完整 Linux VM，不要绕过平台安全策略。

```bash
bash scripts/preflight.sh
python3 -m unittest discover -s tests -v
bash scripts/audit-runtime.sh
bash build.sh
```

构建脚本只在这里拉取上游镜像和安装软件。输出 `langfuse-all-in-one:0.2.0`；`artifacts/` 记录镜像 ID、上游摘要及 Alpine 软件包版本。上游默认候选版本：Langfuse Web/Worker 3.227.1、PostgreSQL 17、ClickHouse 26.8.46.6-alpine、Redis 7.4.12-alpine、MinIO RELEASE.2025-09-07T16-13-09Z。版本与镜像可用性、ABI 兼容性仍需实际构建验证，MinIO 旧版本仅供实验。不要把候选版本当作安全审核结果。镜像摘要在构建时解析，Alpine 包补丁版本只记录未完全锁定，不能保证按源码重建得到相同字节。正式交付应对确切镜像摘要做漏洞/许可证扫描，并评估升级受支持版本。

如需复用已生成并审核过的 `images.lock`，执行 `set -a; source images.lock; set +a; bash build.sh`。如首次构建出错，保留完整日志，不要随意换版本或强制使用特权模式。

## 3. 完全断网验收（必须执行）

```bash
bash tests/offline.sh
```

测试不下载任何镜像或 Python SDK。使用唯一临时容器及新数据卷，通过 `--network none --pull=never` 强制断开外部网络；仅通过 localhost 检查六个服务，使用随机临时账号/API Key 及标准库 HTTP 客户端进行 v3 Trace ingestion/查询，测试重启和删除容器后用原卷重建。测试成功会清除自身临时容器和数据卷，并在 `artifacts/offline-pass.txt` 写入通过测试的镜像 ID。失败会保留对应容器、卷及日志供排查；这些测试数据可能含临时凭证，日志不要直接对外公开。该测试不覆盖浏览器登录、媒体直传、内网跨 Pod 访问、备份恢复、故障注入或长期压力。

如失败，按输出中的容器名执行 `docker logs <name>`、`docker inspect <name>`（inspect 可能暴露测试环境变量）。不要删除失败的数据卷直到问题定位。修复后重新执行 build 和 offline 验收。没有通过验收的镜像不允许由本工程的 export/push 脚本交付。

## 4. 在构建主机进行浏览器验证

```bash
bash run.sh
docker logs -f langfuse-aio
```

另开终端查看 `docker ps`、`docker top langfuse-aio` 和 `docker inspect -f '{{.State.Health.Status}}' langfuse-aio`。本项目应只有一个容器；内部多个进程是正常的。`run.sh` 使用 `--pull=never`、宿主机回环地址端口 3000/9090、独立命名卷 `langfuse-aio-data`。本地访问 http://localhost:3000；远程服务器用 SSH 转发，在自己电脑执行：

```bash
ssh -N -L 3000:127.0.0.1:3000 -L 9090:127.0.0.1:9090 -p SSH_PORT USER@HOST
```

手工注册、创建项目及 API Key，验证 UI、Trace、媒体上传等。在允许内网访问、禁止公网出口的环境中还需重复测试浏览器和 SDK。不要直接暴露本地测试配置到公网。`bash tests/smoke.sh` 会重启本测试容器。

## 5. 交付：二选一（仅在离线验收成功之后）

### A. 阿里云 ACR 企业版

从 IT 获取真实的 ACR 域名、命名空间、仓库、凭证及网络访问方式，先通过授权方式登录，再执行：

```bash
# 替换为实际域名、命名空间、仓库；此处只是占位示例
export ACR_IMAGE='your-acr.example/your-namespace/langfuse-offline:0.2.0'
docker login "${ACR_IMAGE%%/*}"
bash push-acr.sh
```

推送后用 ACR 返回的仓库摘要固定部署。目标节点必须能访问 ACR 私网入口及相关依赖端点，并有拉取权限。K8S 节点负责拉镜像，业务容器不拉其他镜像。IT 若使用 ACK，采用单副本 StatefulSet + PVC 挂载 `/data`；容器端口 3000，媒体需要 9090 或内网反向代理，其他数据库不对外开放。实际平台是否允许 root 初始化、PVC、探针和端口需要 IT 核实，本包未声称已经提供可直接套用的 ACK YAML。

### B. 镜像文件离线导入

```bash
bash export.sh
```

生成 `artifacts/langfuse-offline-all-in-one-0.2.0.tar.gz` 和对应 `.sha256`；仅含一个应用镜像，不包含数据卷、运行时生成的密钥或六个上游镜像作为独立标签。使用 IT 批准的方式传输。目标是 Docker 主机时，在文件目录执行：

```bash
sha256sum -c langfuse-offline-all-in-one-0.2.0.tar.gz.sha256
gzip -dc langfuse-offline-all-in-one-0.2.0.tar.gz | docker load
```

无公网 Docker 主机若需要内网访问，可参考以下命令（替换为 IT 批准的真实内网地址，防火墙限制访问范围）：

```bash
docker run -d --pull=never --name langfuse-aio --restart=no --stop-timeout 150 \
  -p 127.0.0.1:3000:3000 -p 127.0.0.1:9090:9090 \
  -e NEXTAUTH_URL=http://localhost:3000 \
  -e AIO_S3_PUBLIC_URL=http://localhost:9090 \
  -v langfuse-aio-data:/data langfuse-all-in-one:0.2.0
```

上述命令仅绑定宿主机回环地址用于安全验证。正式内网访问要绑定获准的内网地址或走内网反向代理，将 NEXTAUTH_URL 和 AIO_S3_PUBLIC_URL 改为用户可访问且应用可解析的内网地址，配置 TLS。若目标为 containerd/ACK 则优先内部 ACR 或由 IT 执行其平台支持的镜像导入，不要求业务容器安装 Docker。

## 6. 数据与故障

`/data` 存储 PostgreSQL、ClickHouse、Redis、MinIO、持久化密钥 `/data/secrets.json`，务必备份整套数据和密钥，不可删除或共享给其他同时运行的实例。不能用同一卷并发启动两个容器。入口以 root 初始化目录，再切换到低权限服务用户；平台强制 non-root 或只读根文件系统时需要适配。单实例无高可用，不可直接扩副本。进程退出则整体退出，短暂故障由健康检查暴露；当前测试不自动重启，正式平台应配置合理 startup/readiness/liveness 和 150 秒终止窗口，避免迁移期间反复重启。无公网并不意味着没有外部调用尝试；可选 LLM、SSO、SMTP、Webhook 等只能使用获准内网服务。正式生产仍需安全扫描、备份恢复、资源评估与实际 IT 平台验收。

## 7. 本次实际验证范围

源码静态检查、Python 单元测试、Bash 语法检查。当前生成工程的环境没有 Docker daemon，不能声称已构建真实镜像或通过断网测试。ZIP 是工程源代码，不是运行镜像；运行镜像在有网构建主机生成。请先执行 preflight 和 build，把失败日志发回定位。

参考（官方）：
- https://langfuse.com/self-hosting/security/networking
- https://langfuse.com/self-hosting/security/telemetry
- https://langfuse.com/self-hosting/administration/headless-initialization
- https://github.com/langfuse/langfuse/tree/v3.227.1
- https://github.com/langfuse/langfuse/blob/v3.227.1/web/entrypoint.sh
- https://github.com/langfuse/langfuse/blob/v3.227.1/worker/Dockerfile
- https://docs.docker.com/engine/network/drivers/none/
- https://docs.docker.com/reference/cli/docker/container/run/
