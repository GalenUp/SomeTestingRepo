#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
docker info >/dev/null
mkdir -p artifacts
rm -f artifacts/offline-pass.txt
bash scripts/audit-runtime.sh
# Resolve all stage images to repository digests, recording what was used.
keys=(WEB_IMAGE WORKER_IMAGE CH_IMAGE REDIS_IMAGE MINIO_IMAGE)
defaults=(docker.io/langfuse/langfuse:3.227.1 docker.io/langfuse/langfuse-worker:3.227.1 docker.io/clickhouse/clickhouse-server:26.8.46.6-alpine docker.io/library/redis:7.4.12-alpine quay.io/minio/minio:RELEASE.2025-09-07T16-13-09Z)
args=()
lock=images.lock.tmp
: > "$lock"
for i in "${!keys[@]}"; do
  k=${keys[$i]}; ref=${!k:-${defaults[$i]}}
  docker pull --platform linux/amd64 "$ref"
  # Pull ensures the named ref is present; inspect its content-addressed repo digest.
  pinned=$(docker image inspect --format '{{index .RepoDigests 0}}' "$ref")
  [[ "$pinned" == *@sha256:* ]] || { echo "Could not pin $ref" >&2; exit 1; }
  printf '%s=%s\n' "$k" "$pinned" >> "$lock"
  args+=(--build-arg "$k=$pinned")
done
mv "$lock" images.lock
DOCKER_BUILDKIT=1 docker build --platform linux/amd64 --progress=plain "${args[@]}" -t "${AIO_IMAGE:-langfuse-all-in-one:0.2.0}" .

docker image inspect --format '{{.Id}}' "${AIO_IMAGE:-langfuse-all-in-one:0.2.0}" > artifacts/image-id.txt
docker run --rm --pull=never --network none --entrypoint cat "${AIO_IMAGE:-langfuse-all-in-one:0.2.0}" /opt/aio/apk-versions.txt > artifacts/apk-versions.txt
cp images.lock artifacts/images.lock
